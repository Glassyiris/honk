import type {Locator} from '@playwright/test';
import {expect, test} from './fixtures';

// The flat list exercises the virtualizer; grouping (the default) gets its own test below.
// At 1440px the detail opens beside the table and the table keeps its main columns.
test.use({
  viewport: {width: 1440, height: 900},
  storage: {'doona-mock-big': '100', 'doona-connections-view': JSON.stringify({hidden: [], sort: null, group: 'none'})}
});

async function expectRowInView(row: Locator) {
  await expect(row).toBeInViewport();
  await expect
    .poll(() =>
      row.evaluate(element => {
        const rect = element.getBoundingClientRect();
        const grid = element.closest('[role="grid"]')!;
        const header = grid.querySelector('[role="columnheader"]')!.getBoundingClientRect();
        return rect.top >= header.bottom && rect.bottom <= grid.getBoundingClientRect().bottom;
      })
    )
    .toBe(true);
}

test('English Started values fit without truncation', async ({page}) => {
  await page.goto('/#/connections?id=c-0241');
  const row = page.locator('.rp-table [data-key="c-0241"]');
  const started = row.getByRole('gridcell').last().locator('.cell');
  await expect(started).toContainText('minutes ago');
  await page.evaluate(() => document.fonts.ready.then(() => undefined));
  const widths = await started.evaluate(element => ({available: element.clientWidth, text: element.scrollWidth}));
  expect(widths.text).toBeLessThanOrEqual(widths.available);
});

test('connection selection follows clicks, arrows and Home/End across virtual rows', async ({page}) => {
  await page.goto('/#/connections');
  const selected = page.locator('.rp-table [aria-selected="true"]');
  await page.locator('.rp-table [data-key="c-0002"]').click();
  await expect(selected).toHaveAttribute('data-key', 'c-0002');
  await expect(page.locator('.rp-panel .rp-h3')).toHaveText('cdn.bilibili.com');
  await page.keyboard.press('ArrowDown');
  await expect(selected).toHaveAttribute('data-key', 'c-0003');
  await page.keyboard.press('ArrowUp');
  await expect(selected).toHaveAttribute('data-key', 'c-0002');
  await page.keyboard.press('End');
  await expect(selected).toHaveAttribute('aria-rowindex', '1001');
  await expectRowInView(selected);
  await page.keyboard.press('ArrowUp');
  await expect(selected).toHaveAttribute('aria-rowindex', '1000');
  await expectRowInView(selected);
  await page.keyboard.press('Home');
  await expect(selected).toHaveAttribute('data-key', 'c-0001');
  for (let i = 0; i < 20; i++) await page.keyboard.press('ArrowDown');
  await expect(selected).toHaveAttribute('aria-rowindex', '22');
  await expectRowInView(selected);
  expect(await page.locator('.rp-table [role="row"]').count()).toBeLessThan(60);
});

test('connection filtering narrows the collection and renders an empty result', async ({page}) => {
  await page.goto('/#/connections');
  const grid = page.getByRole('grid', {name: 'Connections'});
  const filter = page.locator('.rp-toolbar input');
  await expect(grid).toHaveAttribute('aria-rowcount', '1001');
  await filter.fill('api.telegram.org');
  await expect(grid).toHaveAttribute('aria-rowcount', '151');
  await expect(grid.getByRole('rowheader').first()).toHaveText('api.telegram.org');
  await expect(grid.getByRole('rowheader').filter({hasNotText: 'api.telegram.org'})).toHaveCount(0);
  expect(await page.locator('.rp-table [role="row"]').count()).toBeLessThan(60);
  await filter.fill('no-such-connection.invalid');
  await expect(page.locator('.rp-table .rp-empty')).toBeVisible();
  await expect(grid).toHaveAttribute('aria-rowcount', '1');
  await filter.fill('');
  await expect(grid).toHaveAttribute('aria-rowcount', '1001');
  expect(await page.locator('.rp-table [role="row"]').count()).toBeLessThan(60);
});

test('connection selection survives a runtime poll', async ({page}) => {
  await page.clock.install();
  await page.goto('/#/connections');
  const selected = page.locator('.rp-table [aria-selected="true"]');
  await page.locator('.rp-table [data-key="c-0002"]').click();
  const age = await selected.getByRole('gridcell').last().textContent();
  await page.clock.fastForward(6000);
  await expect(selected).toHaveAttribute('data-key', 'c-0002');
  await expect(selected.getByRole('gridcell').last()).not.toHaveText(age!);
  await expect(page.locator('.rp-panel .rp-h3')).toHaveText('cdn.bilibili.com');
});

test('connection deep links reveal selected rows, including same-route query changes', async ({page}) => {
  await page.goto('/#/connections?id=c-0500');
  const selected = page.locator('.rp-table [aria-selected="true"]');
  await expect(selected).toHaveAttribute('data-key', 'c-0500');
  await expectRowInView(selected);
  await expect(page.locator('.rp-panel .rp-h3')).toHaveText('doubleclick.net');
  await page.evaluate(() => {
    location.hash = '#/connections?id=c-0001';
  });
  await expect(selected).toHaveAttribute('data-key', 'c-0001');
  await expectRowInView(selected);
});

test('1000 connections keep the DOM bounded at the top, middle and bottom', async ({page}) => {
  await page.goto('/#/connections');
  const grid = page.getByRole('grid', {name: 'Connections'});
  await expect(grid).toHaveAttribute('aria-rowcount', '1001');
  await expect(page.locator('.rp-toolbar .rp-badge')).toHaveText('The connection list is truncated; only some records are shown.');
  for (const [fraction, key] of [
    [0, 'c-0001'],
    [0.5, 'c-0667'],
    [1, 'c-0400']
  ] as const) {
    await grid.evaluate((element, fraction) => {
      element.scrollTop = (element.scrollHeight - element.clientHeight) * fraction;
    }, fraction);
    await expect(page.locator(`.rp-table [data-key="${key}"]`)).toBeInViewport();
    expect(await page.locator('.rp-table [role="row"]').count()).toBeLessThan(60);
  }
});

test('column visibility, sorting and grouping persist without expanding the virtual DOM', async ({page}) => {
  await page.goto('/#/connections');
  const grid = page.getByRole('grid', {name: 'Connections'}).or(page.getByRole('treegrid', {name: 'Connections'}));
  await page.getByRole('button', {name: 'Columns', exact: true}).click();
  await page.getByRole('menuitemcheckbox', {name: 'Rule', exact: true}).click();
  await expect(page.getByRole('menuitemcheckbox', {name: 'Rule', exact: true})).toHaveAttribute('aria-checked', 'false');
  await page.keyboard.press('Escape');
  await expect(grid.getByRole('columnheader', {name: 'Rule', exact: true})).toHaveCount(0);
  const target = grid.getByRole('columnheader', {name: 'Target'});
  await target.click();
  await expect(target).toHaveAttribute('aria-sort', 'ascending');
  await expect(grid.getByRole('rowheader').first()).toHaveText('1.1.1.1:53');
  await target.click();
  await expect(target).toHaveAttribute('aria-sort', 'descending');
  await expect(grid.getByRole('rowheader').first()).toHaveText('doubleclick.net');
  await page.getByRole('button', {name: 'Group by'}).click();
  await page.getByRole('option', {name: 'Outbound', exact: true}).click();
  await expect(grid.locator('[role=row][aria-level="1"]').first()).toContainText('block');
  await grid.locator('[role=row][aria-level="2"]').first().click();
  await expect(grid.locator('[aria-selected=true]')).toHaveAttribute('aria-level', '2');
  await page.reload();
  await expect(target).toHaveAttribute('aria-sort', 'descending');
  await expect(grid.getByRole('columnheader', {name: 'Rule', exact: true})).toHaveCount(0);
  await expect(grid.locator('[role=row][aria-level="1"]').first()).toBeVisible();
  for (const fraction of [0, 0.5, 1]) {
    await grid.evaluate((element, fraction) => {
      element.scrollTop = (element.scrollHeight - element.clientHeight) * fraction;
    }, fraction);
    await expect(grid.locator('[role=row][aria-level="2"]').first()).toBeAttached();
    expect(await grid.getByRole('row').count()).toBeLessThan(60);
  }
  await page.getByRole('button', {name: 'Group by'}).click();
  await page.getByRole('option', {name: 'By client', exact: true}).click();
  await grid.evaluate(element => {
    element.scrollTop = 0;
  });
  await expect(grid.locator('[role=row][aria-level="1"]').first()).toContainText('10.0.0.');
});

test.describe('default view', () => {
  test.use({storage: {'doona-mock-big': '100'}, viewport: {width: 1024, height: 768}});

  test('groups by client with counts and opens the selection beside the table', async ({page}) => {
    await page.goto('/#/connections');
    const grid = page.getByRole('treegrid', {name: 'Connections'});
    const groups = grid.locator('[role=row][aria-level="1"]');
    await expect(groups.first()).toContainText('10.0.0.');
    await expect(groups.first()).toContainText('active');
    await expect(page.getByRole('dialog')).toHaveCount(0);
    await grid.locator('[role=row][aria-level="2"]').first().click();
    await expect(page).toHaveURL(/#\/connections\?id=c-\d+$/);
    // Below 1200px the detail is a drawer; Escape closes it and clears the selection.
    const drawer = page.getByRole('dialog');
    await expect(drawer.getByRole('heading')).toBeVisible();
    await page.keyboard.press('Escape');
    await expect(drawer).toHaveCount(0);
    await expect(page).toHaveURL(/#\/connections$/);
    await page.setViewportSize({width: 1440, height: 900});
    await grid.locator('[role=row][aria-level="2"]').first().click();
    await expect(page.locator('.rp-panel').getByRole('heading')).toBeVisible();
    await page.locator('.rp-panel').getByRole('button', {name: 'Only this client', exact: true}).click();
    await expect(page.locator('.rp-toolbar input')).toHaveValue(/^10\.0\.0\.\d+$/);
    await expect(groups).toHaveCount(1);
  });
});

test('closing a connection removes it from the list and clears the selection', async ({page}) => {
  await page.goto('/#/connections?id=c-0001');
  const panel = page.locator('.rp-panel');
  await expect(panel.getByRole('heading', {name: 'api.telegram.org'})).toBeVisible();
  await panel.getByRole('button', {name: 'Close connection', exact: true}).click();
  await expect(page.locator('.rp-toast.positive')).toContainText('Closed api.telegram.org');
  await expect(page).toHaveURL(/#\/connections$/);
  await expect(page.locator('.rp-table [data-key="c-0001"]')).toHaveCount(0);
  // A kernel-observed connection is refused by the backend, and the row stays.
  await page.goto('/#/connections?id=c-0002');
  await panel.getByRole('button', {name: 'Close connection', exact: true}).click();
  await expect(page.locator('.rp-toast.negative')).toContainText('cannot be closed');
  await expect(page.locator('.rp-table [data-key="c-0002"]')).toHaveCount(1);
});

test('the connection list exports the filtered rows as CSV', async ({page}) => {
  await page.goto('/#/connections');
  await page.locator('.rp-toolbar input').fill('api.telegram.org');
  const download = page.waitForEvent('download');
  await page.getByRole('button', {name: 'Export CSV', exact: true}).click();
  const file = await download;
  expect(file.suggestedFilename()).toMatch(/^connections-.*\.csv$/);
  // The download stream is read chunk by chunk; the spec stays free of Node typings.
  const stream = await file.createReadStream();
  const decoder = new TextDecoder();
  let body = '';
  for await (const chunk of stream as AsyncIterable<Uint8Array>) body += decoder.decode(chunk, {stream: true});
  const lines = body.trim().split('\n');
  expect(lines[0]).toBe('id,target,domain,source,network,state,outbound,chain,rule,upload_bytes,download_bytes,started_at');
  expect(lines.length).toBe(151);
  expect(lines.slice(1).every(line => line.includes('api.telegram.org'))).toBe(true);
});
