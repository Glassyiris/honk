import {storageKeys} from './storage';

export type Profile = {id: string; name: string; api: string; token: string};
type Profiles = {profiles: Profile[]; activeId: string};
export type StoragePort = Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>;

// The built-in demo backend: a profile with this address, or none, runs on the in-browser mock.
export const DEMO_API = 'mock';
export function isDemoApi(api: string | undefined): api is typeof DEMO_API | '' | undefined {
  return !api || api === DEMO_API;
}

/** Accept a server root or proxy prefix, never credentials, a query, or a fragment. */
export function normalizeApi(value: string): string {
  const base = value.trim();
  if (isDemoApi(base)) return base;
  if (!/^https?:\/\/[^/]+/i.test(base) || /[\s\\?#]/.test(base)) throw new Error('invalid_url');
  const url = new URL(base);
  if (!url.hostname || url.username || url.password) throw new Error('invalid_url');
  return base.replace(/\/+$/, '');
}

export function normalizeProfiles(value: unknown): Profile[] {
  if (!Array.isArray(value)) return [];
  const ids = new Set<string>();
  return value.flatMap(item => {
    if (!item || typeof item.id !== 'string' || !item.id.trim() || ids.has(item.id) || typeof item.api !== 'string') return [];
    try {
      const api = normalizeApi(item.api);
      ids.add(item.id);
      return [
        {
          id: item.id,
          name: typeof item.name === 'string' && item.name.trim() ? item.name.trim() : api || item.id,
          api,
          token: typeof item.token === 'string' ? item.token : ''
        }
      ];
    } catch {
      return [];
    }
  });
}

// Bumped by every write to the profiles or the session and by another tab's storage event, so a reader that
// caches what it derived from storage (the API client) knows when to look again.
let revision = 0;
export const storageRevision = () => revision;
export const touchStorage = () => void revision++;

let cachedProfiles: {raw: string; profiles: Profile[]} | undefined;
// The profile this page load talks to, endpoint and token included. Another tab choosing or editing a profile changes
// what is saved, not this tab's backend; this tab moves when it saves itself (which reloads) or is reloaded.
let pinned: Profile | undefined;
let profileReadError = false;

export function consumeProfileReadError(): boolean {
  const error = profileReadError;
  profileReadError = false;
  return error;
}

export function readProfiles(storage?: StoragePort): Profiles {
  try {
    const store = storage ?? localStorage;
    let raw = store.getItem(storageKeys.profiles);
    // Preserve first-visit state until a profile is explicitly written.
    if (raw === null && store.getItem(storageKeys.legacyApi) === null) raw = '[]';
    else if (raw === null) {
      const api = store.getItem(storageKeys.legacyApi)!;
      const token = store.getItem(storageKeys.legacyToken) ?? '';
      const profiles = normalizeProfiles([{id: 'legacy', name: api.trim() || DEMO_API, api, token}]);
      raw = JSON.stringify(profiles);
      // Commit the migration marker before removing the old credentials.
      store.setItem(storageKeys.profiles, raw);
      store.setItem(storageKeys.profile, profiles[0]?.id ?? '');
      store.removeItem(storageKeys.legacyApi);
      store.removeItem(storageKeys.legacyToken);
    }
    if (cachedProfiles?.raw !== raw) {
      let profiles: Profile[];
      try {
        profiles = normalizeProfiles(JSON.parse(raw));
      } catch {
        profiles = [];
        profileReadError = true;
      }
      cachedProfiles = {raw, profiles};
    }
    const profiles = cachedProfiles.profiles;
    const saved = () => profiles.find(profile => profile.id === store.getItem(storageKeys.profile));
    if (storage) return {profiles, activeId: saved()?.id ?? profiles[0]?.id ?? ''};
    const own = (pinned ??= saved() ?? profiles[0]);
    return {profiles, activeId: profiles.find(profile => profile.id === own?.id)?.id ?? profiles[0]?.id ?? ''};
  } catch {
    return {profiles: [], activeId: ''};
  }
}

// The active profile as this page load first read it, or as this tab last saved it.
export function pinnedProfile(): Profile | undefined {
  readProfiles();
  return pinned;
}

export function writeProfiles({profiles, activeId}: Profiles, storage?: StoragePort): void {
  const store = storage ?? localStorage;
  const normalized = profiles.map(profile => ({...profile, name: profile.name.trim() || profile.id, api: normalizeApi(profile.api)}));
  const id = normalized.find(profile => profile.id === activeId)?.id ?? normalized[0]?.id ?? '';
  const write = () => {
    store.setItem(storageKeys.profiles, JSON.stringify(normalized));
    store.setItem(storageKeys.profile, id);
  };
  try {
    write();
  } catch {
    // Stored chart history is the first thing to give up when storage is full; a second failure is the caller's.
    dropRings();
    write();
  }
  if (!storage) pinned = normalized.find(profile => profile.id === id);
  touchStorage();
}

function dropRings() {
  try {
    for (const key of Object.keys(localStorage)) if (key.startsWith(storageKeys.ringsPrefix)) localStorage.removeItem(key);
  } catch {
    /* Storage can be unavailable. */
  }
}

// Strip the hosted /ui/ suffix while preserving any reverse-proxy prefix.
export function hostedRoot(loc: {origin: string; pathname: string}): string {
  const prefix = /^(.*?)\/ui(?:\/|$)/.exec(loc.pathname)?.[1] ?? '';
  return loc.origin + prefix;
}

export async function detectHostedBackend(
  storage?: StoragePort,
  loc: {origin: string; pathname: string; protocol: string; host: string} = location,
  fetcher: typeof fetch = fetch
): Promise<boolean> {
  try {
    storage ??= localStorage;
    if (storage.getItem(storageKeys.profiles) !== null || storage.getItem(storageKeys.legacyApi) !== null || !/^https?:$/.test(loc.protocol)) return false;
    const api = hostedRoot(loc);
    const response = await fetcher(`${api}/api`, {headers: {Accept: 'application/json'}, cache: 'no-store', signal: AbortSignal.timeout(3000)});
    const json = response.headers.get('content-type')?.includes('application/json') ?? false;
    const challenged = response.status === 401 && /bearer/i.test(response.headers.get('www-authenticate') ?? '');
    const discovered = response.status === 200 && json && (await response.json())?.api_major === 1;
    if (!challenged && !discovered) return false;
    writeProfiles({profiles: [{id: 'hosted', name: loc.host, api, token: ''}], activeId: 'hosted'}, storage);
    return true;
  } catch {
    return false;
  }
}
