import {useContext, useEffect, useRef, useState, type CSSProperties, type ReactNode} from 'react';
import {
  Button as RButton,
  UNSTABLE_Toast as RToast,
  UNSTABLE_ToastContent as ToastContent,
  UNSTABLE_ToastList as ToastList,
  UNSTABLE_ToastQueue as ToastQueue,
  UNSTABLE_ToastRegion as ToastRegion,
  UNSTABLE_ToastStateContext as ToastStateContext,
  Text,
  type ToastState
} from 'react-aria-components';
import Close from './icons/Close';
import CheckmarkCircle from './icons/CheckmarkCircle';
import AlertTriangle from './icons/AlertTriangle';
import InfoCircle from './icons/InfoCircle';
import {useT, type Translator} from '../i18n';
import {errorText, failureNotice} from '../api/error';
import {cx} from './cx';
import {Button, TextTooltip} from './Button';

export function Empty({role, children}: {role?: 'alert'; children: ReactNode}) {
  return (
    <div className="rp-empty" role={role}>
      {children}
    </div>
  );
}

export function Loading({children}: {children?: ReactNode}) {
  const t = useT();
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 150);
    return () => clearTimeout(timer);
  }, []);
  return (
    <div className="rp-empty" role="status" data-wait={visible ? undefined : ''}>
      <span className="rp-spinner" aria-hidden="true" />
      {children ?? t('ui.loading')}
    </div>
  );
}

// A message about a whole form or view, as S2's InlineAlert: a negative one takes focus when it appears after a
// submit, so the result is announced where the person is looking.
export function InlineAlert({
  tone = 'negative',
  title,
  children,
  action,
  takeFocus
}: {
  tone?: 'negative' | 'informative';
  title?: string;
  children: ReactNode;
  action?: ReactNode;
  takeFocus?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (takeFocus) ref.current?.focus();
  }, [takeFocus]);
  return (
    <div ref={ref} role={tone === 'negative' ? 'alert' : 'status'} tabIndex={takeFocus ? -1 : undefined} className={cx('rp-alert', tone)}>
      {title && <strong className="rp-alert-title">{title}</strong>}
      <span>{children}</span>
      {action}
    </div>
  );
}

// Retry refetches the failed resource rather than reloading the page.
// `message` replaces the load-failure wording for a failed action.
export function ErrorMessage({error, onRetry, message}: {error: Error | null | undefined; onRetry?: () => void; message?: string}) {
  const t = useT();
  return error ? (
    <InlineAlert
      action={
        onRetry && (
          <Button small quiet onPress={onRetry}>
            {t('ui.retry')}
          </Button>
        )
      }
    >
      {message ?? t('ui.loadFailed', {error: errorText(error, t)})}
    </InlineAlert>
  ) : null;
}

// Without children the light is the dot alone, for a place that names the state elsewhere.
export function Light({tone, children, small}: {tone: 'ok' | 'warn' | 'err' | 'info' | 'neutral' | 'muted'; children?: ReactNode; small?: boolean}) {
  return <span className={cx('rp-light', tone, small && 'sm')}>{children != null && <span>{children}</span>}</span>;
}
export function Bar({label, value, pct, color}: {label: ReactNode; value: string; pct: number; color: string}) {
  return (
    <div className="rp-bar">
      <div className="top">
        <span className="l">{typeof label === 'string' ? <TextTooltip>{label}</TextTooltip> : label}</span>
        <span className="v">{value}</span>
      </div>
      <div className="track" aria-hidden="true">
        <div className="fill" style={{width: `${Math.max(0, Math.min(100, pct))}%`, background: color}} />
      </div>
    </div>
  );
}

export function Badge({children, tone, className, tip}: {children: ReactNode; tone?: 'warn'; className?: string; tip?: string}) {
  return (
    <TextTooltip className={cx('rp-badge', tone, className)} text={tip}>
      {children}
    </TextTooltip>
  );
}

// `row` keeps label and value on one line; a third element is the full value, shown as a tooltip.
export function Kv({items, inline, row}: {items: Array<[string, string] | [string, string, string]>; inline?: boolean; row?: boolean}) {
  return (
    <div className={cx('rp-kv', (inline || row) && 'inline', row && 'row')}>
      {items.map(([k, v, full]) => (
        <div key={k}>
          <span className="k">{k}</span>
          {full ? (
            <TextTooltip className="v" text={full}>
              {v}
            </TextTooltip>
          ) : (
            <span className="v">{v}</span>
          )}
        </div>
      ))}
    </div>
  );
}

// Toasts: react-aria's queue rendered like S2's ToastContainer; timers pause while hovered, focused or listed.
type ToastKind = 'positive' | 'negative' | 'neutral' | 'info';
type ToastMessage = {kind: ToastKind; text: string};
const toasts = new ToastQueue<ToastMessage>({maxVisibleToasts: 5});
// A repeated message replaces its earlier copy at the front instead of stacking behind it.
const queued = new Map<string, string>();
export const toast = (kind: ToastKind, text: string) => {
  const id = kind + '\n' + text;
  const earlier = queued.get(id);
  if (earlier) toasts.close(earlier);
  const key = toasts.add(
    {kind, text},
    {
      timeout: 5000,
      onClose: () => {
        if (queued.get(id) === key) queued.delete(id);
      }
    }
  );
  queued.set(id, key);
};
// A failed action's toast; `wrap` words the failure. An unknown operation outcome is shown on its own, neutrally.
export const toastFailure = (error: unknown, t: Translator, wrap: (error: string) => string) => {
  const notice = failureNotice(error, t, wrap);
  toast(notice.kind, notice.text);
};
const TOAST_ICON = {positive: CheckmarkCircle, negative: AlertTriangle, info: InfoCircle, neutral: null};
export function Toasts() {
  const t = useT();
  const [expanded, setExpanded] = useState(false);
  useEffect(() => {
    if (expanded) toasts.pauseAll();
    else toasts.resumeAll();
  }, [expanded]);
  // The list closes with its last toast; the region itself unmounts then.
  useEffect(
    () =>
      toasts.subscribe(() => {
        if (toasts.visibleToasts.length === 0) setExpanded(false);
      }),
    []
  );
  useEffect(() => {
    if (!expanded) return;
    // One Escape closes one layer: an open dialog takes it unless focus is in the toasts themselves.
    const on = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      const inToasts = (e.target as Element | null)?.closest?.('.rp-toasts');
      if (inToasts || !document.querySelector('[role="dialog"], [role="alertdialog"]')) setExpanded(false);
    };
    addEventListener('keydown', on);
    return () => removeEventListener('keydown', on);
  }, [expanded]);
  return (
    <ToastRegion queue={toasts} className={cx('rp-toasts', expanded && 'expanded')}>
      {expanded && <RButton className="rp-toast-underlay" aria-label={t('toast.collapse')} onPress={() => setExpanded(false)} />}
      {expanded && (
        <div className="rp-toast-controls">
          <RButton className="rp-btn sm" onPress={() => toasts.clear()}>
            {t('toast.clearAll')}
          </RButton>
          <RButton className="rp-btn sm" onPress={() => setExpanded(false)}>
            {t('toast.collapse')}
          </RButton>
        </div>
      )}
      <ToastStack expanded={expanded} onExpand={() => setExpanded(true)} />
    </ToastRegion>
  );
}
function ToastStack({expanded, onExpand}: {expanded: boolean; onExpand: () => void}) {
  const t = useT();
  const state = useContext(ToastStateContext) as ToastState<ToastMessage>;
  const visible = state.visibleToasts;
  return (
    <ToastList<ToastMessage> className="rp-toast-list">
      {({toast: item}) => {
        // The queue lists the newest first; behind it, the depth sets a toast's offset and scale.
        const depth = visible.indexOf(item);
        const background = !expanded && depth > 0;
        const Icon = TOAST_ICON[item.content.kind];
        return (
          <RToast
            toast={item}
            className={cx('rp-toast', item.content.kind, background && 'background')}
            style={{zIndex: visible.length - depth, '--i': Math.min(depth, 3)} as CSSProperties}
            inert={background || undefined}
          >
            <div className="main">
              <ToastContent className="body">
                {Icon && <Icon />}
                <Text slot="title" className="grow">
                  {item.content.text}
                </Text>
              </ToastContent>
              {!expanded && depth === 0 && visible.length > 1 && (
                <RButton className="rp-btn sm quiet more" onPress={onExpand}>
                  {t('toast.showAllCount', {n: visible.length})}
                </RButton>
              )}
            </div>
            <RButton slot="close" className="rp-btn quiet icon close" aria-label={t('close')}>
              <Close />
            </RButton>
          </RToast>
        );
      }}
    </ToastList>
  );
}
