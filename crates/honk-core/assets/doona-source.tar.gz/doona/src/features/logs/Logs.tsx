import {useMemo} from 'react';
import {LogActivity} from './Activity';
import {useT} from '../../i18n';
import {Button, DataTable, ErrorMessage, LabeledSelect, Light, Switch, TextField, TextTooltip, type TableColumn} from '../../ui/ui';
import {useLogs} from './useLogs';
import Download from '../../ui/icons/Download';

type LogRow = ReturnType<typeof useLogs>['rows'][number];

export function Logs() {
  const t = useT();
  const vm = useLogs();
  // Stable column definitions: a new array on every stream tick would re-render every visible row.
  const columns = useMemo(
    (): TableColumn<LogRow>[] => [
      {
        id: 'ts',
        label: t('ui.time'),
        minWidth: 200,
        grow: 0,
        drop: 2,
        render: record => (
          <TextTooltip className="rp-code" text={record.iso}>
            {record.timestamp}
          </TextTooltip>
        )
      },
      {
        id: 'level',
        label: t('log.level'),
        minWidth: 90,
        grow: 0,
        drop: 3,
        render: record => (
          <Light small tone={record.tone}>
            {record.levelText}
          </Light>
        )
      },
      {id: 'target', label: t('log.target'), minWidth: 160, grow: 0, drop: 1, render: record => <span className="rp-code">{record.target}</span>},
      {
        id: 'message',
        label: t('log.message'),
        minWidth: 280,
        grow: 3,
        isRowHeader: true,
        render: record => <TextTooltip>{record.message}</TextTooltip>
      }
    ],
    [t]
  );
  return (
    <div className="rp-page">
      <div className="rp-toolbar">
        <LabeledSelect side label={t('log.level')} value={vm.level} onChange={vm.setLevel} items={vm.levels} />
        <TextField search label={t('log.target')} value={vm.target} width={240} placeholder={t('log.targetPlaceholder')} onChange={vm.setTarget} />
        <Switch isSelected={vm.paused} onChange={vm.setPaused}>
          {t('log.pause')}
        </Switch>
        <Light small tone={vm.status.tone}>
          {vm.status.text}
        </Light>
        <span className="rp-grow" />
        <Button isDisabled={!vm.rows.length} onPress={vm.clear}>
          {t('log.clear')}
        </Button>
        <Button isDisabled={!vm.rows.length} onPress={vm.export}>
          <Download />
          {t('log.export')}
        </Button>
      </div>
      <ErrorMessage error={vm.error} onRetry={vm.retry} />
      <LogActivity records={vm.records} offered={vm.offered} minimum={vm.level} setMinimum={vm.setLevel} />
      <DataTable label={t('nav.logs')} stream rows={vm.rows} height={640} loading={vm.loading} empty={t('log.empty')} cols={columns} />
    </div>
  );
}
