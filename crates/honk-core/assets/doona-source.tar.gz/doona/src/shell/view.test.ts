import {afterEach, beforeEach, expect, it, vi} from 'vitest';
import {ApiError} from '../api/error';
import {capabilitiesBase, version} from '../api/mock/fixtures';
import {readSettings} from './preferences';
import {translate} from '../i18n';
import {accessError, shellView} from './view';
import {hubs, routePaths} from './routes';

const settings = readSettings({getItem: () => null, setItem: () => {}, removeItem: () => {}});
const t = translate.bind(null, 'en');
beforeEach(() => vi.stubEnv('VITE_ENGINE_ORG', 'https://github.com/daeuniverse'));
afterEach(() => vi.unstubAllEnvs());
it('uses the same capability policy for navigation, shortcuts and content', () => {
  const capabilities = structuredClone(capabilitiesBase);
  capabilities.resources.connections.available = false;
  const view = shellView(settings, 'connections', capabilities, null, version, null, t);
  expect(view.groups.flatMap(group => group.items).find(item => item.path === 'connections')).toMatchObject({current: true, unavailable: true});
  expect(view.shortcutPaths.c).toBeUndefined();
  expect(view.content).toEqual({kind: 'unavailable'});
  expect(view.backend.text).toContain(version.engine.version);
  expect(view.about.items.some(([, value]) => value.includes(version.api.name))).toBe(true);
});
it('reports the backend state from discovery and the version read alone', () => {
  const refused = new ApiError(401, 'authentication_required', 'token required');
  const unreachable = new ApiError(500, 'internal_error', 'Discovery failed');
  const state = (capabilities: typeof capabilitiesBase | undefined, capabilityError: Error | null, versionError: Error | null) => {
    const {tone, state, label} = shellView(settings, 'activity', capabilities, capabilityError, capabilities && version, versionError, t).backend;
    return {tone, state, label};
  };
  expect(state(capabilitiesBase, null, null)).toEqual({
    tone: 'ok',
    state: 'Connected',
    label: `Backend: ${version.engine.name} ${version.engine.version}, Connected`
  });
  expect(state(undefined, null, null)).toMatchObject({tone: 'neutral', state: 'Connecting'});
  expect(state(undefined, refused, null)).toMatchObject({tone: 'warn', state: 'Sign-in required'});
  expect(state(undefined, unreachable, null)).toMatchObject({tone: 'err', state: 'Unreachable'});
  expect(state(capabilitiesBase, null, new Error('Version failed'))).toMatchObject({tone: 'warn', state: 'Connected, version unknown'});
  const facts = shellView(settings, 'activity', capabilitiesBase, null, version, null, t).backend.facts;
  expect(facts).toContainEqual(['Backend URL', 'Built-in demo data']);
});
it('waits for discovery and yields protected pages to login without blocking settings', () => {
  expect(shellView(settings, 'connections', undefined, null, undefined, null, t).content.kind).toBe('loading');
  const error = new ApiError(401, 'authentication_required', 'token required');
  const configured = {...settings, profiles: [{id: 'router', name: 'Router', api: 'https://router.test', token: 'old'}], activeId: 'router'};
  expect(shellView(configured, 'connections', undefined, error, undefined, null, t).content).toEqual({
    kind: 'login',
    profileId: 'router',
    api: 'https://router.test',
    backend: 'Router',
    rejected: true
  });
  expect(shellView(configured, 'settings', undefined, error, undefined, null, t).content.kind).toBe('page');
});

it('surfaces discovery failures and suppresses authentication only on the login surface', () => {
  const discovery = new ApiError(500, 'internal_error', 'Discovery failed');
  const versionError = new Error('Version failed');
  const view = shellView(settings, 'config', undefined, discovery, undefined, versionError, t);
  expect(view.content.kind).toBe('page');
  expect(view.error).toBe(discovery);
  const auth = new ApiError(401, 'authentication_required', 'Token required');
  expect(shellView(settings, 'config', undefined, auth, undefined, versionError, t).error).toBe(versionError);
  expect(shellView(settings, 'settings', undefined, auth, undefined, null, t).error).toBe(auth);
  // Before sign-in the version read is refused too; the login surface shows no error banner for it.
  expect(shellView(settings, 'config', undefined, auth, undefined, auth, t).error).toBeNull();
});

it('asks for sign-in when a read is refused, even while discovery reports a failure of its own', () => {
  const configured = {...settings, profiles: [{id: 'router', name: 'Router', api: 'https://router.test', token: ''}], activeId: 'router'};
  const unavailable = new ApiError(503, 'unavailable', 'Discovery unavailable');
  const refused = new ApiError(401, 'authentication_required', 'session expired');
  const view = shellView(configured, 'connections', capabilitiesBase, accessError(unavailable, refused), version, null, t);
  expect(view.content.kind).toBe('login');
  expect(view.error).toBeNull();
  expect(shellView(configured, 'connections', capabilitiesBase, accessError(unavailable, null), version, null, t).error).toBe(unavailable);
});
it('puts every page in exactly one hub and shows the hubs as the navigation sections', () => {
  expect(hubs.flatMap(hub => hub.pages).sort()).toEqual([...routePaths].sort());
  const view = shellView(settings, 'dns', capabilitiesBase, null, version, null, t);
  expect(view.groups.map(group => [group.label, group.items.map(item => item.path)])).toEqual([
    ['Overview', ['overview', 'activity']],
    ['Traffic', ['connections', 'dns', 'logs', 'events']],
    ['Routing', ['policies', 'nodes', 'rules']],
    ['Settings', ['settings', 'config']]
  ]);
});
