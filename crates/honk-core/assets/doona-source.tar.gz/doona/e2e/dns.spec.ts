import type {Page} from '@playwright/test';
import {dnsCache} from '../src/api/mock/fixtures';
import {downloadText, expect, mockBackend, test} from './fixtures';
import {createMockApi} from '../src/api/mock';
import {ApiError} from '../src/api/error';
import {test as browserTest} from '@playwright/test';

test('a resolution record opens beside the log with its answers', async ({page}) => {
  await page.setViewportSize({width: 1440, height: 900});
  await page.goto('/#/dns?tab=log');
  const rows = page.locator('.rp-table').locator('[role=rowgroup]:last-child [role=row][data-key]');
  await expect(rows.first()).toBeVisible();
  const first = rows.first();
  const name = (await first.getByRole('rowheader').innerText()).trim();
  await first.click();
  const panel = page.locator('.rp-panel');
  await expect(panel.getByRole('heading', {name})).toBeVisible();
  await expect(panel.locator('.rp-kv')).toContainText('Route source');
  await expect(panel.locator('.rp-code, .rp-empty').first()).toBeVisible();
  await panel.getByRole('button', {name: 'Close', exact: true}).click();
  await expect(panel).toHaveCount(0);
});

test('the DNS page fits without overflow at phone width with the drawer', async ({page}) => {
  await page.setViewportSize({width: 400, height: 800});
  await page.goto('/#/dns?tab=log');
  const rows = page.locator('.rp-table').locator('[role=rowgroup]:last-child [role=row][data-key]');
  await rows.first().click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog')).toHaveCount(0);
});

async function nativeDns(page: Page) {
  const api = createMockApi();
  const capabilities = await api.capabilities();
  capabilities.resources.events.available = false;
  const responses: Record<string, unknown> = {
    '/capabilities': capabilities,
    '/version': await api.version(),
    '/runtime': await api.runtime(),
    '/groups': await api.groups(),
    '/nodes': await api.nodes()
  };
  await page.addInitScript(() => localStorage.setItem('doona-api', location.origin));
  await page.route('**/api/v1/**', async route => {
    const path = new URL(route.request().url()).pathname.replace('/api/v1', '');
    if (!(path in responses)) throw new Error(`Unexpected request: ${route.request().method()} ${path}`);
    await route.fulfill({json: responses[path]});
  });
}

test('the cache lists all 818 entries through bounded summary pages and refreshes them', async ({page}) => {
  await nativeDns(page);
  await page.clock.install();
  let entries = Array.from({length: 818}, (_, index) => ({
    ...dnsCache.entries[0],
    entry_id: `cache-${index + 1}`,
    domain: `cached-${index + 1}.example.`,
    type: 'TXT',
    answers: undefined
  }));
  const requests: URLSearchParams[] = [];
  await page.route('**/api/v1/dns/cache?*', async route => {
    const query = new URL(route.request().url()).searchParams;
    requests.push(query);
    const offset = Number(query.get('cursor')?.split(':')[1] ?? 0);
    const limit = Number(query.get('limit') ?? 100);
    const full = query.get('detail') === 'full';
    const rows = entries.slice(offset, offset + limit).map(entry => ({
      ...entry,
      ...(full ? {answers: [{name: entry.domain, type: 'TXT', class: 'IN', ttl: 60, data: `"${'x'.repeat(3000)}"`}]} : {})
    }));
    // Model the native response's conservative metadata and RR projection budget.
    const bytes = rows.reduce((size, entry) => size + 512 + entry.entry_id.length + entry.domain.length + JSON.stringify(entry.answers ?? []).length, 1024);
    if (bytes > 262144)
      return route.fulfill({
        status: 503,
        json: {error: {code: 'temporarily_unavailable', message: 'DNS observation is temporarily unavailable'}, request_id: 'cache-budget'}
      });
    const end = offset + rows.length;
    await route.fulfill({json: {...dnsCache, total: entries.length, entries: rows, next_cursor: end < entries.length ? `snapshot:${end}` : null}});
  });
  await page.goto('/#/dns?tab=cache');
  const grid = page.getByRole('grid', {name: 'Cache', exact: true});
  await expect(grid).toHaveAttribute('aria-rowcount', '819');
  await expect(grid.getByRole('rowheader').first()).toHaveText('cached-1.example.');
  await grid.evaluate(element => {
    element.scrollTop = element.scrollHeight;
  });
  await expect(grid.getByRole('rowheader', {name: 'cached-818.example.', exact: true})).toBeVisible();
  expect(requests.map(query => query.get('cursor'))).toEqual([null, ...Array.from({length: 8}, (_, index) => `snapshot:${(index + 1) * 100}`)]);
  for (const query of requests) {
    expect(query.get('limit')).toBe('100');
    expect(query.get('detail')).toBe('summary');
    expect(query.has('domain')).toBe(false);
  }
  entries = entries.slice(0, -1);
  await page.clock.runFor(15000);
  await expect(grid).toHaveAttribute('aria-rowcount', '818');
  await expect(grid.getByRole('rowheader', {name: 'cached-817.example.', exact: true})).toBeVisible();
});

test('domain filtering precedes cache snapshot admission and never narrows global flush', async ({page}) => {
  await nativeDns(page);
  const entries = [
    {...dnsCache.entries[0], domain: 'api.Telegram.org.', answers: undefined},
    {...dnsCache.entries[0], entry_id: 'c2', domain: 'cdn.telegram.org.', answers: undefined}
  ];
  const requests: URLSearchParams[] = [];
  let flushed = false;
  await page.route('**/api/v1/dns/cache?*', async route => {
    const query = new URL(route.request().url()).searchParams;
    requests.push(query);
    if (!flushed && query.get('domain')?.toLowerCase() !== 'telegram')
      return route.fulfill({
        status: 503,
        json: {error: {code: 'temporarily_unavailable', message: 'DNS observation is temporarily unavailable'}, request_id: 'snapshot-budget'}
      });
    const offset = query.get('cursor') ? 1 : 0;
    await route.fulfill({
      json: {
        ...dnsCache,
        total: flushed ? 0 : 2,
        entries: flushed ? [] : entries.slice(offset, offset + 1),
        next_cursor: !flushed && offset === 0 ? 'filtered:1' : null
      }
    });
  });
  await page.route('**/api/v1/dns/cache/flush', async route => {
    expect(route.request().method()).toBe('POST');
    expect(route.request().postDataJSON()).toEqual({});
    expect(new URL(route.request().url()).search).toBe('');
    flushed = true;
    await route.fulfill({json: {matched: 818, deleted: 818}});
  });
  await page.goto('/#/dns?tab=cache&domain=TeLeGrAm');
  const grid = page.getByRole('grid', {name: 'Cache', exact: true});
  await expect(grid.getByRole('rowheader')).toHaveText(['api.Telegram.org.', 'cdn.telegram.org.']);
  await expect(page.locator('.rp-toolbar .rp-kv')).toContainText('2');
  expect(requests.map(query => query.get('domain'))).toEqual(['telegram', 'telegram']);
  expect(requests.map(query => query.get('cursor'))).toEqual([null, 'filtered:1']);
  await page.getByRole('button', {name: 'Clear all cache', exact: true}).click();
  const dialog = page.getByRole('alertdialog', {name: 'Clear all cache', exact: true});
  await dialog.getByRole('button', {name: 'Clear all cache', exact: true}).click();
  await expect(grid.getByRole('rowheader', {name: /telegram\.org\./i})).toHaveCount(0);
  await expect(page.locator('.rp-toolbar .rp-kv')).toContainText('0');
  await page.getByRole('button', {name: 'Domain: TeLeGrAm', exact: true}).click();
  await expect.poll(() => requests.at(-1)?.has('domain')).toBe(false);
});

test('all supported DNS types are queried in bounded batches and shown together', async ({page}) => {
  const api = createMockApi();
  const capabilities = await api.capabilities();
  for (const resource of Object.values(capabilities.resources)) resource.available = false;
  capabilities.resources.dns_query.available = true;
  capabilities.resources.dns_query.record_types = ['A', 'AAAA', 'TXT'];
  capabilities.resources.dns_query.limits!.max_types_per_request = 1;
  await page.addInitScript(() => localStorage.setItem('doona-api', location.origin));
  await page.route('**/api/v1/capabilities', route => route.fulfill({json: capabilities}));
  await page.route('**/api/v1/version', async route => route.fulfill({json: await api.version()}));
  const requested: string[][] = [];
  await page.route('**/api/v1/dns/query?*', async route => {
    const params = new URL(route.request().url()).searchParams;
    const types = params.getAll('type');
    requested.push(types);
    expect(types).toHaveLength(1);
    await route.fulfill({json: await api.dnsQuery(params.get('domain')!, types)});
  });
  await page.goto('/#/dns?domain=example.com&type=all');
  await page.getByRole('button', {name: 'Query', exact: true}).click();
  await expect(page.getByRole('heading', {name: 'example.com. TXT', exact: true})).toBeVisible();
  await expect(page.getByRole('heading', {name: 'example.com. A', exact: true})).toBeVisible();
  await expect(page.getByRole('heading', {name: 'example.com. AAAA', exact: true})).toBeVisible();
  expect(requested).toEqual([['A'], ['AAAA'], ['TXT']]);
});

test('DNS tabs preserve linked query drafts', async ({page}) => {
  await page.goto('/#/dns?domain=example.com&type=AAAA');
  await page.getByRole('tab', {name: 'Cache', exact: true}).click();
  await expect(page).toHaveURL(/domain=example.com/);
  await page.getByRole('tab', {name: 'Query', exact: true}).click();
  await expect(page.getByRole('textbox', {name: 'Domain', exact: true})).toHaveValue('example.com');
  await page.getByRole('button', {name: 'Query', exact: true}).click();
  await expect(page.getByRole('heading', {name: 'example.com. AAAA', exact: true})).toBeVisible();
});

test('DNS logs load older pages and export only loaded records', async ({page}) => {
  const api = createMockApi();
  const capabilities = await api.capabilities();
  capabilities.resources.events.available = false;
  capabilities.resources.dns_log.max_page_size = 1;
  const seed = await api.dnsLog();
  const records = seed.records.slice(0, 2);
  const cursors: Array<string | null> = [];
  await page.addInitScript(() => localStorage.setItem('doona-api', location.origin));
  await page.route('**/api/v1/capabilities', route => route.fulfill({json: capabilities}));
  await page.route('**/api/v1/version', async route => route.fulfill({json: await api.version()}));
  await page.route('**/api/v1/runtime', async route => route.fulfill({json: await api.runtime()}));
  await page.route('**/api/v1/dns/log?*', async route => {
    const params = new URL(route.request().url()).searchParams;
    const cursor = params.get('cursor');
    cursors.push(cursor);
    expect(params.get('limit')).toBe('1');
    await route.fulfill({json: {...seed, total: 500, records: [records[cursor ? 1 : 0]], next_cursor: cursor ? null : 'older'}});
  });
  await page.goto('/#/dns?tab=log');
  await expect(page.getByText('1 loaded; the export covers loaded records only', {exact: true})).toBeVisible();
  await expect(page.getByText('500 records in the ring buffer', {exact: true})).toBeVisible();
  await page.getByRole('button', {name: 'Load older records'}).click();
  // Everything is loaded now, so the qualifier goes away.
  await expect(page.getByText(/loaded; the export covers/)).toHaveCount(0);
  expect(cursors).toContain('older');
  await expect(page.getByRole('button', {name: 'Load older records'})).toHaveCount(0);
  const download = page.waitForEvent('download');
  await page.getByRole('button', {name: 'Export CSV'}).click();
  const stream = await (await download).createReadStream();
  let body = '';
  for await (const chunk of stream as AsyncIterable<Uint8Array>) body += new TextDecoder().decode(chunk);
  expect(body.trim().split('\n')).toHaveLength(3);
  for (const record of records) expect(body).toContain(record.id);
});

browserTest('a transient DNS refusal stays pending until the advertised retry succeeds', async ({page}) => {
  const api = createMockApi();
  const capabilities = await api.capabilities();
  for (const resource of Object.values(capabilities.resources)) resource.available = false;
  capabilities.resources.dns_query.available = true;
  const times: number[] = [];
  const errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.addInitScript(() => {
    localStorage.setItem('doona-api', location.origin);
    localStorage.setItem('doona-lang', 'en');
  });
  await page.route('**/api/v1/capabilities', route => route.fulfill({json: capabilities}));
  await page.route('**/api/v1/version', async route => route.fulfill({json: await api.version()}));
  await page.route('**/api/v1/dns/query?*', async route => {
    times.push(Date.now());
    if (times.length === 1)
      return route.fulfill({status: 429, headers: {'Retry-After': '1'}, json: {error: {code: 'rate_limited', message: 'Wait'}, request_id: 'dns-refused'}});
    return route.fulfill({json: await api.dnsQuery('example.com', ['A'])});
  });
  await page.goto('/#/dns?domain=example.com');
  await page.getByRole('button', {name: 'Query', exact: true}).click();
  await expect(page.getByRole('heading', {name: 'example.com. A', exact: true})).toBeVisible();
  expect(times).toHaveLength(2);
  expect(times[1] - times[0]).toBeGreaterThanOrEqual(1000);
  await expect(page.locator('.rp-toast.negative')).toHaveCount(0);
  expect(errors).toEqual([]);
});

test('paging holds the DNS window through new arrivals until Refresh', async ({page}) => {
  const {api, capabilities, handlers} = await mockBackend(page);
  capabilities.resources.dns_log.max_page_size = 2;
  const seed = await api.dnsLog();
  const record = seed.records[0];
  let arrived = false;
  let heads = 0;
  handlers['GET dns/log'] = async request => {
    const cursor = new URL(request.url()).searchParams.get('cursor');
    if (!cursor) heads++;
    const ids = cursor ? ['d2', 'd1'] : arrived ? ['d5', 'd4'] : ['d4', 'd3'];
    return {...seed, records: ids.map(id => ({...record, id, question: {...record.question, name: id + '.test'}})), next_cursor: cursor ? null : 'older'};
  };
  await page.clock.install();
  await page.goto('/#/dns?tab=log');
  await page.getByRole('button', {name: 'Load older records'}).click();
  const rows = page.getByRole('grid', {name: 'Resolution log'}).getByRole('rowheader');
  await expect(rows).toHaveText(['d4.test', 'd3.test', 'd2.test', 'd1.test']);
  const before = heads;
  arrived = true;
  await page.clock.fastForward(5100);
  await expect.poll(() => heads).toBeGreaterThan(before);
  await expect(page.getByText('Newer records are waiting. Refresh replaces the loaded records.', {exact: true})).toBeVisible();
  await expect(rows).toHaveText(['d4.test', 'd3.test', 'd2.test', 'd1.test']);
  const downloading = page.waitForEvent('download');
  await page.getByRole('button', {name: 'Export CSV'}).click();
  const body = await downloadText(await downloading);
  for (const id of ['d4', 'd3', 'd2', 'd1']) expect(body).toContain(id + '.test');
  expect(body).not.toContain('d5.test');
  await page.getByRole('tabpanel', {name: 'Resolution log'}).getByRole('button', {name: 'Refresh', exact: true}).click();
  await expect(rows).toHaveText(['d5.test', 'd4.test']);
  await expect(page.getByRole('button', {name: 'Load older records'})).toBeVisible();
  await expect(page.getByText(/Newer records are waiting/)).toHaveCount(0);
});

test('DNS source filters send IP literals only on head and older requests', async ({page}) => {
  const {api, capabilities, handlers, requests} = await mockBackend(page);
  capabilities.resources.dns_log.max_page_size = 1;
  const seed = await api.dnsLog();
  handlers['GET dns/log'] = async request => ({
    ...seed,
    records: seed.records.slice(0, 1),
    next_cursor: new URL(request.url()).searchParams.has('cursor') ? null : 'older'
  });
  await page.goto('/#/dns?tab=log');
  const source = page.getByRole('searchbox', {name: 'Device', exact: true});
  await source.fill('2001:db8::1');
  await expect.poll(() => requests.filter(request => new URL(request.url()).searchParams.get('src') === '2001:db8::1').length).toBeGreaterThan(0);
  await page.getByRole('button', {name: 'Load older records'}).click();
  await expect
    .poll(
      () =>
        requests.filter(request => {
          const params = new URL(request.url()).searchParams;
          return params.get('src') === '2001:db8::1' && params.has('cursor');
        }).length
    )
    .toBe(1);
  await source.fill('10.0.0.12:53211');
  await expect(page.getByRole('button', {name: 'Load older records'})).toBeVisible();
  await page.getByRole('button', {name: 'Load older records'}).click();
  const logRequests = requests.filter(request => new URL(request.url()).pathname === '/api/v1/dns/log');
  expect(logRequests.every(request => !new URL(request.url()).searchParams.get('src')?.includes('53211'))).toBe(true);
});

test('the resolution log refresh shows its request pending', async ({page}) => {
  const {api, handlers} = await mockBackend(page);
  await page.goto('/#/dns?tab=log');
  await expect(page.getByRole('grid', {name: 'Resolution log'}).getByRole('rowheader').first()).toBeVisible();
  let release!: () => void;
  const gate = new Promise<void>(resolve => (release = resolve));
  handlers['GET dns/log'] = async () => {
    await gate;
    return api.dnsLog({});
  };
  // The top bar has a Refresh icon button of its own; this is the one in the log's toolbar.
  const refresh = page.locator('.rp-toolbar').getByRole('button', {name: 'Refresh', exact: true});
  await refresh.click();
  await expect(refresh).toHaveAttribute('data-pending');
  release();
  await expect(refresh).not.toHaveAttribute('data-pending');
});

test('Retry after a failed older page asks for that page again and keeps the loaded records', async ({page}) => {
  const {api, capabilities, handlers} = await mockBackend(page);
  capabilities.resources.dns_log.max_page_size = 2;
  const seed = await api.dnsLog();
  const record = seed.records[0];
  let fail = true;
  const cursors: string[] = [];
  handlers['GET dns/log'] = async request => {
    const cursor = new URL(request.url()).searchParams.get('cursor');
    if (cursor) {
      cursors.push(cursor);
      if (fail) throw new ApiError(500, 'internal', 'Older records unavailable');
    }
    const ids = cursor ? ['d2', 'd1'] : ['d4', 'd3'];
    return {...seed, records: ids.map(id => ({...record, id, question: {...record.question, name: id + '.test'}})), next_cursor: cursor ? null : 'older'};
  };
  await page.clock.install();
  await page.goto('/#/dns?tab=log');
  const rows = page.getByRole('grid', {name: 'Resolution log'}).getByRole('rowheader');
  await expect(rows).toHaveText(['d4.test', 'd3.test']);
  await page.getByRole('button', {name: 'Load older records'}).click();
  const alert = page.getByRole('alert').filter({hasText: 'Older records unavailable'});
  await expect(alert).toBeVisible();
  fail = false;
  await alert.getByRole('button', {name: 'Retry', exact: true}).click();
  await expect(rows).toHaveText(['d4.test', 'd3.test', 'd2.test', 'd1.test']);
  await expect(alert).toHaveCount(0);
  expect(cursors).toEqual(['older', 'older']);
});

test('a failed query stays on the query tab', async ({page}) => {
  const {handlers} = await mockBackend(page);
  handlers['GET dns/query'] = async () => {
    throw new ApiError(500, 'internal', 'Resolver offline');
  };
  await page.goto('/#/dns?tab=query&domain=example.com');
  await page.getByRole('button', {name: 'Query', exact: true}).click();
  const alert = page.getByRole('alert').filter({hasText: 'Resolver offline'});
  await expect(page.getByRole('tabpanel', {name: 'Query'}).getByRole('alert').filter({hasText: 'Resolver offline'})).toBeVisible();
  await page.getByRole('tab', {name: 'Cache', exact: true}).click();
  await expect(alert).toBeHidden();
  await page.getByRole('tab', {name: 'Query', exact: true}).click();
  await expect(alert).toBeVisible();
});
